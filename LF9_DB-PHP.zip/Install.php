<?php

// Zugriff auf Datenbank 

$DBConnection = new mysqli("127.0.0.1", "SQL-Admin", "9b9GCVhtBxPQtp6mv2yy", "DB-Doubtful-Joy-SE");    	// Speichern der Zugangsdaten für die DB auf die Variable DBConnection ( IP-Server, User, Passwort, Name Datenbank )

if($DBConnection->connect_error)											// Abfrage ob Verbindung nicht erfolgreich
{
	die("<br>Verbindung fehlgeschlagen: ". $DBConnection->connect_error);		// Ausgabe Des Fehlers
}else
{
	echo "<br>Verbindung erfolgreich";											// Ausgabe Verbindung erfolgreich
}

// Prüfen ob Tabellen vorhanden, wenn ja dann Löschen

echo "<p style=\"font-weight: bold; color: green;\">Löschen aller Tabellen</p>";
								
	$DBConnection->query('SET foreign_key_checks = 0');					// Deaktivieren von Fremdschlüsselbeziehungen/checks
	
	if ($result = $DBConnection->query("SHOW TABLES"))					// Auslesen aller Tabellen, das ergebniss wird auf result gespeichert
	{
		while($row = $result->fetch_array(MYSQLI_NUM))					// Zeilenweises durchgehen von result, Auslesen des aktuellen Tabellennamen
		{
			$DBConnection->query('DROP TABLE IF EXISTS '.$row[0]);		// Löschen der aktuellen Tabelle
		}
	}
	$DBConnection->query('SET foreign_key_checks = 1');					// Fremdschlüsselchecks wieder aktivieren. 



// Erstellen Tabelle USER

// Erstellen des SQL-Statement zum Erstellen der Tabelle und Speichern dieser auf der Variable query
$query = "CREATE TABLE USER													
(
	ID 			INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	USERNAME 	TEXT,
	PASSWORD 	TEXT,
	USERLEVEL 	INT,
	STATUS		BOOL
	
)";																			

if(mysqli_query($DBConnection,$query))										// Ausführen des SQL-Statments durch mysqli_query für die Verbindung DBConnection mit dem Statement welches auf query gespeichert ist
{																			// Das if prüft ob alles erfolgreich ausgeführt wurde
	echo "<br>Tabelle angelegt";												// Wenn ja dann kurze Rückmeldung
}else
{
	echo "<br>Fehler beim Anlegen" . mysqli_error($DBConnection);				// Wenn nein dann Rückmeldung + Fehler
}

// Erstellen Admin User
$PW = password_hash('KWLVyTgwP99H23Bx4D2b', PASSWORD_DEFAULT);
$query = "INSERT INTO USER	(	USERNAME,	PASSWORD,	USERLEVEL,	STATUS)
				VALUES		(	'Admin',	'$PW',	'0',		'1')";

if(mysqli_query($DBConnection,$query))										// Ausführen des SQL-Statments durch mysqli_query für die Verbindung $DBConnection mit dem Statement welches auf query gespeichert ist
{																			// Das if prüft ob alles erfolgreich ausgeführt wurde
	echo "<br>User Admin angelegt";												// Wenn ja dann kurze Rückmeldung
}else
{
	echo "<br>Fehler : " . mysqli_error($DBConnection);							// Wenn nein dann Rückmeldung + Fehler
}

// Erstellen Tabelle TICKETS
$query = "CREATE TABLE USER													
(
	ID 			INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	Kunde 		TEXT,
	Betreff 	TEXT,
	Level	 	INT,
	STATUS		BOOL
	
)";	

if(mysqli_query($DBConnection,$query))										// Ausführen des SQL-Statments durch mysqli_query für die Verbindung DBConnection mit dem Statement welches auf query gespeichert ist
{																			// Das if prüft ob alles erfolgreich ausgeführt wurde
	echo "<br>Tabelle angelegt";												// Wenn ja dann kurze Rückmeldung
}else
{
	echo "<br>Fehler beim Anlegen" . mysqli_error($DBConnection);				// Wenn nein dann Rückmeldung + Fehler
}

?>