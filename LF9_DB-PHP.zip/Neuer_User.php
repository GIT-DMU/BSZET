<?php
// Zugriff auf Datenbank 

$DBConnection = new mysqli("127.0.0.1", "SQL-Admin", "9b9GCVhtBxPQtp6mv2yy", "DB-Doubtful-Joy-SE");    	// Speichern der Zugangsdaten für die DB auf die Variable DBConnection ( IP-Server, User, Passwort, Name Datenbank )

if($DBConnection->connect_error)											// Abfrage ob Verbindung nicht erfolgreich
{
	die("<br>Verbindung fehlgeschlagen: ". $DBConnection->connect_error);		// Ausgabe Des Fehlers
}else
{
	echo "<br>Verbindung erfolgreich";											// Ausgabe Verbindung erfolgreich
}

$password = 'password';
$hash = password_hash($password, PASSWORD_DEFAULT);
$username = 'TESTER';
$query = "INSERT INTO USER	(	USERNAME,	PASSWORD,	USERLEVEL,	STATUS)
				VALUES		(	'$username',	'$hash',	'0',		'1')";					

if(mysqli_query($DBConnection,$query))										// Ausführen des SQL-Statments durch mysqli_query für die Verbindung $DBConnection mit dem Statement welches auf query gespeichert ist
{																			// Das if prüft ob alles erfolgreich ausgeführt wurde
	echo "<br>User $username angelegt";												// Wenn ja dann kurze Rückmeldung
}else
{
	echo "<br>Fehler : " . mysqli_error($DBConnection);							// Wenn nein dann Rückmeldung + Fehler
}
?>