<?php

session_start();							// Starten oder Weiterführen einer Session 


$Login = $_POST["login"];					// Übername der Daten aus dem Formular ( Login ) auf eigene Variable
$Password = $_POST["password"];				// Übername der Daten aus dem Formular ( Password ) auf eigene Variable



echo "<br>Debuginfo: Übernommene Daten";	// Ausgabe der Übernommenen Daten
echo "<br>Login: ". $Login;					// Login 
echo "<br>Password: ". $Password;			// Password






// Zugriff auf Datenbank 

$DBConnection = new mysqli("127.0.0.1", "SQL-Admin", "9b9GCVhtBxPQtp6mv2yy", "DB-Doubtful-Joy-SE");    		// Speichern der Zugangsdaten für die DB auf die Variable DBConnection ( IP-Server, User, Passwort, Name Datenbank )

if($DBConnection->connect_error)													// Abfrage ob Verbindung nicht erfolgreich
{
	die("<br>Verbindung fehlgeschlagen: ". $DBConnection->connect_error);			// Ausgabe Des Fehlers
}else
{
	echo "<br>Verbindung erfolgreich";												// Ausgabe Verbindung erfolgreich
}



// Prüfen ob User Vorhanden + Auslesen der Daten


$query = "	SELECT * 
			FROM `user`
			WHERE USERNAME = '". $Login ."'
			LIMIT 1

		";																	// Erstellung der SQL Abfrage
		 
echo "<br>". $query;		 

$erg = mysqli_query($DBConnection,$query);									// Anfrage an die DB

$row = mysqli_fetch_object($erg);											// Auslesen der Aktuellen Zeile des Ergebnis

echo "<br>". mysqli_num_rows( $erg );										// Debug info, was wurde ausgelesen

// Hashwert
$PWmatch = password_verify($Password,$row->PASSWORD);

// Vergleichen ob Password Korrekt

if (mysqli_num_rows( $erg ) > 0)															// Sicherstellen das zu dem Username auch etwas gefunden wurde
{
	if($row->PASSWORD == $PWmatch)
	{
		if($row->STATUS == 1)									// User Vorhanden + Password Korrekt >> Login
		{ 
			echo "<br> Login Korrekt";
			
			$_SESSION["UserID"] = $row->ID;
			
			echo "Debug Session UserID: ". $_SESSION["UserID"]; 
			
			echo ("<meta http-equiv='refresh' content='3; url=./002-FrontEnd/index.php'>");		// Umleitung auf den internen Bereich
		}
		else 																					// User Vorhanden Passwort Falsch >> Zurück 
		{ 
			echo "<br> Fehlgeschlagen";
			
			session_destroy();
			echo ("<meta http-equiv='refresh' content='3; url=index.php'>");					// Umleitung auf die Loginseite
		}
	}else
	{
		echo "<br> Passwort falsch!";
			
			session_destroy();
			echo ("<meta http-equiv='refresh' content='3; url=index.php'>");
	}
}
else 																						// User nicht vorhanden >> Zurück 
{
	echo "<br> username nicht vorhanden";
	session_destroy();
	echo ("<meta http-equiv='refresh' content='3; url=index.php'>");						// Umleitung auf die Loginseite
	
}


?>