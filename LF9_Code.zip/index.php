

<?php
    echo ("<meta http-equiv='refresh' content='1; url=./001-Login/index.php'>");        // Weiterleitung an 001-Login
?>